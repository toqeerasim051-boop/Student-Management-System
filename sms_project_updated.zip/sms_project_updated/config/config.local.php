<?php
// =============================================
// LOCAL CONFIGURATION — DO NOT COMMIT THIS FILE
// Copy config.example.php to config.local.php
// and fill in your values.
// =============================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'sms_db');
define('SITE_NAME', 'EduManage SMS');
define('SITE_URL',  'http://localhost/sms-project');
