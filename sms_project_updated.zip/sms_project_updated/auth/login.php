<?php
require_once '../includes/auth.php';
require_once '../config/db.php';

if (isset($_SESSION['user_id'])) {
    $role = $_SESSION['role'];
    header("Location: ../$role/dashboard.php");
    exit;
}

$error = '';
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'];
$script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
preg_match('#(/[^/]*sms[^/]*)#i', $script, $m);
$base = $protocol . '://' . $host . ($m[1] ?? '/sms-project');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email && $password) {
        $stmt = $conn->prepare("SELECT id, name, email, password, role, status FROM users WHERE email = ? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($user && $user['status'] === 'active' && password_verify($password, $user['password'])) {
            // Prevent session fixation — regenerate ID on privilege change
            session_regenerate_id(true);

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];

            // Get entity id (student_id or teacher_id)
            if ($user['role'] === 'student') {
                $s = $conn->prepare("SELECT id FROM students WHERE user_id = ?");
                $s->bind_param("i", $user['id']);
                $s->execute();
                $row = $s->get_result()->fetch_assoc();
                $_SESSION['entity_id'] = $row['id'] ?? null;
                $s->close();
            } elseif ($user['role'] === 'teacher') {
                $s = $conn->prepare("SELECT id FROM teachers WHERE user_id = ?");
                $s->bind_param("i", $user['id']);
                $s->execute();
                $row = $s->get_result()->fetch_assoc();
                $_SESSION['entity_id'] = $row['id'] ?? null;
                $s->close();
            }

            logAction($conn, $user['id'], $user['role'], 'Login', '', 'Logged in successfully');
            header("Location: $base/{$user['role']}/dashboard.php");
            exit;
        } else {
            $error = 'Invalid email or password. Please try again.';
        }
    } else {
        $error = 'Please enter both email and password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — EduManage SMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= $base ?>/assets/css/style.css">
    <style>
        .demo-accounts { margin-top: 20px; border-top: 1px solid var(--border); padding-top: 16px; }
        .demo-accounts h4 { font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; color: var(--text-dim); margin-bottom: 12px; }
        .demo-item {
            display: flex; justify-content: space-between;
            padding: 8px 12px; border-radius: 8px;
            background: var(--surface2); margin-bottom: 6px;
            font-size: 12px; cursor: pointer;
            border: 1px solid var(--border);
            transition: border-color 0.2s;
        }
        .demo-item:hover { border-color: var(--primary); }
        .demo-item .role { font-weight: 700; }
        .role-admin { color: var(--danger); }
        .role-teacher { color: var(--success); }
        .role-student { color: var(--primary); }
        .login-btn { width: 100%; justify-content: center; padding: 12px; font-size: 15px; margin-top: 20px; }
        .theme-btn-login {
            position: fixed; top: 16px; right: 16px;
            width: 36px; height: 36px;
            background: var(--surface); border: 1px solid var(--border);
            border-radius: 8px; cursor: pointer;
            display: flex; align-items: center; justify-content: center;
            color: var(--text-muted);
        }
    </style>
</head>
<body>
<button class="theme-btn-login" onclick="toggleTheme()"><i class="fas fa-moon" id="themeIcon"></i></button>

<div class="login-page">
    <div class="login-box">
        <div class="login-logo">
            <div class="logo-icon"><i class="fas fa-graduation-cap"></i></div>
            <h2>EduManage SMS</h2>
            <p>Student Management System</p>
        </div>

        <?php if ($error): ?>
        <div class="alert alert-error"><i class="fas fa-times-circle"></i> <?= h($error) ?></div>
        <?php endif; ?>

        <form method="POST" id="loginForm">
            <?= csrfField() ?>
            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" id="emailField" placeholder="Enter your email" required
                       value="<?= h($_POST['email'] ?? '') ?>">
            </div>
            <div class="form-group" style="margin-top:14px;">
                <label>Password</label>
                <div style="position:relative;">
                    <input type="password" name="password" id="passField" placeholder="Enter your password" required>
                    <button type="button" onclick="togglePass()" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--text-dim);cursor:pointer;font-size:14px;">
                        <i class="fas fa-eye" id="eyeIcon"></i>
                    </button>
                </div>
            </div>
            <button type="submit" class="btn btn-primary login-btn">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
        </form>

        <div class="demo-accounts">
            <h4>🧪 Demo Accounts (click to fill)</h4>
            <div class="demo-item" onclick="fillLogin('admin@sms.com','Admin@123')">
                <span><span class="role role-admin">👑 Admin</span> — admin@sms.com</span>
                <span style="color:var(--text-dim);">See README</span>
            </div>
            <div class="demo-item" onclick="fillLogin('ali@sms.com','Teacher@123')">
                <span><span class="role role-teacher">👨‍🏫 Teacher</span> — ali@sms.com</span>
                <span style="color:var(--text-dim);">See README</span>
            </div>
            <div class="demo-item" onclick="fillLogin('sara@sms.com','Teacher@123')">
                <span><span class="role role-teacher">👩‍🏫 Teacher</span> — sara@sms.com</span>
                <span style="color:var(--text-dim);">See README</span>
            </div>
            <div class="demo-item" onclick="fillLogin('ahmed@sms.com','Student@123')">
                <span><span class="role role-student">🎓 Student</span> — ahmed@sms.com</span>
                <span style="color:var(--text-dim);">See README</span>
            </div>
        </div>
    </div>
</div>

<script src="<?= $base ?>/assets/js/script.js"></script>
<script>
function fillLogin(email, pass) {
    document.getElementById('emailField').value = email;
    document.getElementById('passField').value = pass;
}
function togglePass() {
    const f = document.getElementById('passField');
    const i = document.getElementById('eyeIcon');
    if (f.type === 'password') { f.type = 'text'; i.classList.replace('fa-eye','fa-eye-slash'); }
    else { f.type = 'password'; i.classList.replace('fa-eye-slash','fa-eye'); }
}
</script>
</body>
</html>
