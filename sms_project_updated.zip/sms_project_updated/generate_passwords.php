<?php
/**
 * Run this script ONCE from the command line or browser to generate
 * secure password hashes for setup.sql.
 *
 * CLI:  php generate_passwords.php
 * Then copy the INSERT lines into setup.sql
 */

$passwords = [
    'admin'   => 'Admin@123',
    'teacher' => 'Teacher@123',
    'student' => 'Student@123',
];

echo "=== Secure Password Hashes ===\n\n";
foreach ($passwords as $role => $pw) {
    $hash = password_hash($pw, PASSWORD_DEFAULT);
    echo "$role  ($pw):\n  $hash\n\n";
}

echo "=== SQL snippet for setup.sql ===\n\n";
$adminHash   = password_hash($passwords['admin'],   PASSWORD_DEFAULT);
$teacherHash = password_hash($passwords['teacher'], PASSWORD_DEFAULT);
$studentHash = password_hash($passwords['student'], PASSWORD_DEFAULT);

echo "-- Paste these into setup.sql to replace the INSERT INTO users lines:\n\n";
echo "INSERT INTO users (name, email, password, role) VALUES\n";
echo "('System Admin', 'admin@sms.com', '$adminHash', 'admin');\n\n";
echo "INSERT INTO users (name, email, password, role) VALUES\n";
echo "('Mr. Ali Hassan', 'ali@sms.com', '$teacherHash', 'teacher'),\n";
echo "('Ms. Sara Khan', 'sara@sms.com', '$teacherHash', 'teacher'),\n";
echo "('Mr. Usman Malik', 'usman@sms.com', '$teacherHash', 'teacher');\n\n";
echo "INSERT INTO users (name, email, password, role) VALUES\n";
echo "('Ahmed Raza', 'ahmed@sms.com', '$studentHash', 'student'),\n";
echo "('Fatima Noor', 'fatima@sms.com', '$studentHash', 'student'),\n";
echo "('Hassan Ali', 'hassan@sms.com', '$studentHash', 'student'),\n";
echo "('Ayesha Bibi', 'ayesha@sms.com', '$studentHash', 'student'),\n";
echo "('Zain Ul Abideen', 'zain@sms.com', '$studentHash', 'student'),\n";
echo "('Hina Tariq', 'hina@sms.com', '$studentHash', 'student');\n\n";

echo "=== Done. Delete this file after use. ===\n";
